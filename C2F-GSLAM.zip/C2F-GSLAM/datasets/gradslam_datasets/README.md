# GradSLAM Datasets

This folder contains the dataloaders used for ConceptFusion (GradSLAM).

Source Code: https://github.com/gradslam/gradslam/pull/58