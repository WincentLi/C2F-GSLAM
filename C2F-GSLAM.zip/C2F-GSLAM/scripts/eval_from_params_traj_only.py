# 本程序主要用于进行提取traj，格式w2c

import os
import argparse
import numpy as np
import torch
import yaml
from datetime import datetime
from tqdm import tqdm

from datasets.gradslam_datasets import load_dataset_config, ReplicaDataset, TUMDataset
from utils.slam_external import build_rotation
from importlib.machinery import SourceFileLoader

def align(model, data):
    model_zerocentered = model - model.mean(1).reshape((3, -1))
    data_zerocentered = data - data.mean(1).reshape((3, -1))
    W = np.zeros((3, 3))
    for column in range(model.shape[1]):
        W += np.outer(model_zerocentered[:, column], data_zerocentered[:, column])
    U, d, Vh = np.linalg.svd(W.T)
    S = np.eye(3)
    if np.linalg.det(U) * np.linalg.det(Vh) < 0:
        S[2, 2] = -1
    rot = U @ S @ Vh
    trans = data.mean(1).reshape((3, 1)) - rot @ model.mean(1).reshape((3, 1))
    model_aligned = rot @ model + trans
    alignment_error = model_aligned - data
    trans_error = np.sqrt(np.sum(np.multiply(alignment_error, alignment_error), 0))
    return rot, trans, trans_error


def evaluate_ate(gt_traj, est_traj):
    gt_traj_pts = [gt[:3, 3] for gt in gt_traj]
    est_traj_pts = [est[:3, 3] for est in est_traj]
    gt_traj_pts = torch.stack(gt_traj_pts).cpu().numpy().T
    est_traj_pts = torch.stack(est_traj_pts).cpu().numpy().T
    _, _, trans_error = align(gt_traj_pts, est_traj_pts)
    return trans_error.mean()

def load_scene_data(scene_path):
    params = dict(np.load(scene_path, allow_pickle=True))
    return {k: torch.tensor(v).cuda().float() for k, v in params.items()}

from datasets.gradslam_datasets import ScannetDataset

def get_dataset(config_dict, basedir, sequence):
    dataset_name = config_dict["dataset_name"].lower()
    if dataset_name in ["replica", "replica_betterkf"]:
        return ReplicaDataset(config_dict, basedir, sequence)
    elif dataset_name in ["tum", "tum_betterkf"]:
        return TUMDataset(config_dict, basedir, sequence)
    elif dataset_name in ["scannet"]:
        return ScannetDataset(config_dict, basedir, sequence)  # ✅ 新增支持
    else:
        raise ValueError(f"Unsupported dataset: {dataset_name}")


def save_poses_as_scannet_format(poses_w2c, output_pose_folder):
    os.makedirs(output_pose_folder, exist_ok=True)
    for i, w2c in enumerate(poses_w2c):
        pose_np = w2c.cpu().numpy()
        pose_file = os.path.join(output_pose_folder, f"{i}.txt")
        with open(pose_file, "w") as f:
            for row in pose_np:
                row_str = " ".join(f"{val:.6f}" for val in row)
                f.write(row_str + "\n")


def main(config_dict_path, basedir, sequence, scene_path, results_path=None):
    # === 加载配置和数据集 ===
    dataset_cfg = load_dataset_config(config_dict_path)
    dataset = get_dataset(dataset_cfg, basedir, sequence)  # 夹在GT
    num_frames = len(dataset)

    # === 加载估计的场景位姿 ===
    final_params = load_scene_data(scene_path)

    # === 获取GT位姿 ===
    gt_w2c_list = []
    for i in tqdm(range(num_frames), desc="Loading GT poses"):
        _, _, _, gt_pose = dataset[i]
        gt_w2c_list.append(torch.linalg.inv(gt_pose))

    # === 获取估计位姿 ===
    est_w2c_list = []
    for i in range(num_frames):
        cam_rot = torch.nn.functional.normalize(final_params['cam_unnorm_rots'][..., i])
        cam_trans = final_params['cam_trans'][..., i]
        w2c = torch.eye(4).cuda()
        w2c[:3, :3] = build_rotation(cam_rot)
        w2c[:3, 3] = cam_trans
        est_w2c_list.append(w2c)

    # === 评估 ATE ===
    ate_rmse = evaluate_ate(gt_w2c_list, est_w2c_list)
    print("Final ATE RMSE: {:.2f} cm".format(ate_rmse * 100))

    # === 这里是保存轨迹的地方，判断是否为 scannet 格式，调用对应保存函数 ===
    if "scannet" in dataset_cfg["dataset_name"].lower():
        # ScanNet 保存成 pose/0.txt, pose/1.txt ...
        pose_folder = os.path.join(os.path.dirname(results_path), "pose")
        save_poses_as_scannet_format(est_w2c_list, pose_folder)
        print(f"Saved ScanNet-style poses to folder: {pose_folder}")
    else:
        # 其他数据集，保存为单个 traj.txt 文件（原有行为）
        with open(results_path, "w") as f:
            for w2c in est_w2c_list:
                w2c_np = w2c.cpu().numpy()
                w2c_rowmajor = w2c_np.reshape(-1)  # 行主序
                f.write(" ".join(f"{v:.6f}" for v in w2c_rowmajor) + "\n")

    # === 保存结果 ===
    results_dir = os.path.dirname(results_path)
    os.makedirs(results_dir, exist_ok=True)
    with open(os.path.join(results_dir, "pose_eval.txt"), "w") as f:
        f.write("ATE RMSE: {:.2f} cm\n".format(ate_rmse * 100))

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("config_dict", type=str, help="Path to YAML config file")
    args = parser.parse_args()

    experiment = SourceFileLoader(
        os.path.basename(args.config_dict), args.config_dict
    ).load_module()
    yaml = experiment.config['data']['gradslam_data_cfg']
    dataset_root = experiment.config['data']['basedir']
    sequence_name = experiment.scene_name

    results_dir = os.path.join(
        experiment.config["workdir"], experiment.config["run_name"]
    )
    npz_path = os.path.join(results_dir, 'params.npz')
    print(npz_path)
    pose_file_name_dict = {
        'tum': 'pose.txt',
        'tum_coarse': 'pose.txt',
        'replica': 'traj.txt',
        'replica_coarse': 'traj.txt',
    }
    output_format = experiment.group_name.lower()
    if output_format in pose_file_name_dict:
        pose_name = pose_file_name_dict[output_format]
    else:
        raise ValueError(f"Unknown dataset name {output_format}")

    if output_format in ['tum', 'tum_coarse']:
        sequence_name = 'rgbd_dataset_' + sequence_name

    output_path = os.path.join(results_dir, pose_name)
    print(output_path)

    main(yaml, dataset_root, sequence_name, npz_path, output_path)
