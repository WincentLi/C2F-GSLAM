'''
基于共视关系和滑动窗口进行关键帧的选择和管理
'''
import torch


def should_add_keyframe(
    cur_frame_idx: int,
    last_kf_idx: int,
    cur_pose: torch.Tensor,
    last_kf_pose: torch.Tensor,
    cur_visibility: torch.Tensor,
    last_kf_visibility: torch.Tensor,
    median_depth: float,
    config: dict
) -> bool:
    """
    判断当前帧是否应当作为新关键帧加入。
    条件：
    1. 固定间隔帧总是加入关键帧
    2. 或者满足原来的 overlap / translation / rotation / interval 策略
    """
    cur_pose = cur_pose.detach().cpu()
    last_kf_pose = last_kf_pose.detach().cpu()
    cur_visibility = cur_visibility.detach().cpu()
    last_kf_visibility = last_kf_visibility.detach().cpu()

    kf_selection = config.get('kf_selection')
    kf_translation_ratio = kf_selection['kf_translation_ratio']
    keyframe_overlap = kf_selection['keyframe_overlap']
    min_kf_interval = kf_selection['min_kf_interval']
    min_kf_gap = kf_selection['min_kf_gap']
    angle_threshold = kf_selection['angle_threshold']
    fixed_interval = kf_selection.get('fixed_interval', 5)  # 固定间隔帧

    # ---- 固定间隔帧强制加入 ----
    if cur_frame_idx % fixed_interval == 0:
        print(f"[Frame {cur_frame_idx}] Added as fixed interval keyframe.")
        return True

    # ---- 原关键帧筛选策略 ----
    union = torch.logical_or(cur_visibility, last_kf_visibility).sum()
    intersect = torch.logical_and(cur_visibility, last_kf_visibility).sum()
    if union == 0:
        overlap_ratio = 1.0
        min_kf_gap = min_kf_interval
    else:
        overlap_ratio = intersect / union

    rel_pose = torch.linalg.inv(cur_pose) @ last_kf_pose
    translation = torch.norm(rel_pose[:3, 3])
    dist_check = translation > kf_translation_ratio * median_depth

    R_rel = cur_pose[:3, :3] @ last_kf_pose[:3, :3].T
    trace = torch.clamp((torch.trace(R_rel) - 1) / 2, -1.0, 1.0)
    rot_angle = torch.acos(trace)
    rot_check = rot_angle > angle_threshold

    should_add = (
        (overlap_ratio < keyframe_overlap
        or dist_check
        or rot_check
        or (cur_frame_idx - last_kf_idx >= min_kf_interval))
        and (cur_frame_idx - last_kf_idx >= min_kf_gap)
    )

    print(f"[Frame {cur_frame_idx}] Decision by original strategy: {should_add}")
    return should_add


def update_keyframe_window(
    current_window: list,
    cur_idx: int,
    cur_pose: torch.Tensor,
    cur_vis: torch.Tensor,
    kf_dict: dict,
    window_size: int = 6,
    min_overlap: float = 0.4
) -> list:
    """
    更新滑动窗口关键帧：
    - 移除与当前帧重叠太低的关键帧；
    - 保持窗口大小不超过 window_size；
    - 自动处理可见性掩码维度不一致的问题。
    """
    cur_vis = cur_vis.detach().cpu()
    new_window = [cur_idx] + current_window
    to_remove = []

    for idx in current_window:
        vis = kf_dict[idx]['vis'].detach().cpu()

        # === 对齐长度 ===
        min_len = min(cur_vis.shape[0], vis.shape[0])
        cur_vis_trimmed = cur_vis[:min_len]
        vis_trimmed = vis[:min_len]

        if vis_trimmed.sum() == 0 or cur_vis_trimmed.sum() == 0:
            continue

        intersect = torch.logical_and(cur_vis_trimmed, vis_trimmed).sum()
        denom = torch.minimum(cur_vis_trimmed.sum(), vis_trimmed.sum())

        if denom == 0:
            continue

        overlap = intersect / denom

        if overlap < min_overlap:
            to_remove.append(idx)

    for idx in to_remove:
        if idx in new_window:
            new_window.remove(idx)

    if len(new_window) > window_size:
        new_window = new_window[:window_size]

    return new_window

